export default function Page() {
  return (
   <>
   Hello Teacher Dashboard
   </>
  );
}
