export default function Page() {
  return (
   <>
   Hello Admin Dashboard
   </>
  );
}
