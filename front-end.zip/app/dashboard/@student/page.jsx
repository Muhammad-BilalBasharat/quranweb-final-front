export default function Page() {
  return (
   <>
   Hello Student Dashboard
   </>
  );
}